Visit project home page [http://alexbarinov.github.com/UIBubbleTableView/](http://alexbarinov.github.com/UIBubbleTableView/) for installation guide and example preview. 

You are always welcome to ask questions, leave comments and report bugs with [https://github.com/AlexBarinov/UIBubbleTableView/issues](https://github.com/AlexBarinov/UIBubbleTableView/issues)

Developed in StexGroup, LLC [http://www.stexgroup.com](http://www.stexgroup.com)

This work is licensed under the Creative Commons Attribution-ShareAlike 3.0 Unported License. To view a copy of this license, visit [http://creativecommons.org/licenses/by-sa/3.0/](http://creativecommons.org/licenses/by-sa/3.0/)