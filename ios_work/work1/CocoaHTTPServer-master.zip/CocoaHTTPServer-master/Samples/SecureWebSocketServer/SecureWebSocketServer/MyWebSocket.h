#import <Foundation/Foundation.h>
#import "WebSocket.h"


@interface MyWebSocket : WebSocket
{
	
}

@end
