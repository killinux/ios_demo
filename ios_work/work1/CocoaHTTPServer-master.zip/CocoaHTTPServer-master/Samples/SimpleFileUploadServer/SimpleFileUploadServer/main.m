//
//  main.m
//  SimpleFileUploadServer
//
//  Created by Валерий Гаврилов on 16.04.12.
//  Copyright (c) 2012 muhtau1@gmail.com. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc, (const char **)argv);
}
