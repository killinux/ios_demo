//
//  main.m
//  SecureHTTPServer
//
//  Created by Robbie Hanson on 5/19/09.
//  Copyright Deusty Designs, LLC. 2009. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc,  (const char **) argv);
}
