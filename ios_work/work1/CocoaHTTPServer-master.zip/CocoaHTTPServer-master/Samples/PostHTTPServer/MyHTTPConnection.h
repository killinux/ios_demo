#import <Cocoa/Cocoa.h>
#import "HTTPConnection.h"


@interface MyHTTPConnection : HTTPConnection

@end