//
//  ViewController.h
//  BubbleDemo
//
//  Created by xiao7 on 14/10/19.
//  Copyright (c) 2014年 killinux. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
{

    IBOutlet UITableView *tableViewList;
    IBOutlet UITextField *messageTxt;
}
@property (nonatomic, strong) NSMutableArray *resultArray;

@end

