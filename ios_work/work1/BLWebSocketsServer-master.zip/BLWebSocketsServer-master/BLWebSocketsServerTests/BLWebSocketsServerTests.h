//
//  BLWebSocketsServerTests.h
//  BLWebSocketsServerTests
//
//  Created by Benjamin Loulier on 1/22/13.
//  Copyright (c) 2013 Benjamin Loulier. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface BLWebSocketsServerTests : SenTestCase

@end
