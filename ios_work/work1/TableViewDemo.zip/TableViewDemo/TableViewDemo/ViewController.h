//
//  ViewController.h
//  TableViewDemo
//
//  Created by xiao7 on 14-10-18.
//  Copyright (c) 2014年 killinux. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController<UITableViewDelegate,UITableViewDataSource,UITextFieldDelegate>{
    IBOutlet UITableView *tableViewList;
    NSMutableArray *dataItems;
    
    IBOutlet UITextField *talktxt;
}



@end

