iOSSnippet
==============================

Code snippet on iOS

1, SQLiteDemo
Demonstate how to use sqlite on iOS, such as open/close database, create table, insert/update/delete record.

2, CorePlotDemo
Demonstate how to use CorePlot on iOS, display xygraph and scatter space.
Sreenshots:https://github.com/kesalin/iOSSnippet/blob/master/CorePlotDemo/Note01.png

3, KSUtilitiesDemo
iOS utilities.

4, KSNetworkDemo
Demonstate network programming with socket, CFNetwork, Bonjour on iOS.

